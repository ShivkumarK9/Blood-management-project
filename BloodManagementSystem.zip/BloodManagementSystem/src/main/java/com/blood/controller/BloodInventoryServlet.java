package com.blood.controller;

import com.blood.dao.BloodInventoryDAO;
import com.blood.model.BloodInventory;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BloodInventoryServlet")
public class BloodInventoryServlet extends HttpServlet {
    private BloodInventoryDAO inventoryDAO;
    private static final int RECORDS_PER_PAGE = 5; // Pagination setting

    @Override
    public void init() {
        inventoryDAO = new BloodInventoryDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if (action == null || action.equals("list")) {
                listInventory(request, response);
            } else if (action.equals("new")) {
                showNewForm(request, response);
            } else if (action.equals("edit")) {
                showEditForm(request, response);
            } else if (action.equals("delete")) {
                confirmDelete(request, response);
            } else if (action.equals("search")) {
                searchInventory(request, response);
            }
        } catch (Exception e) {
            handleError(request, response, "Error processing request: " + e.getMessage());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if (action.equals("add")) {
                addInventory(request, response);
            } else if (action.equals("update")) {
                updateInventory(request, response);
            } else if (action.equals("delete")) {
                deleteInventory(request, response);
            } else {
                listInventory(request, response);
            }
        } catch (Exception e) {
            handleError(request, response, "Error processing request: " + e.getMessage());
        }
    }

    private void listInventory(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Pagination parameters
            int page = 1;
            if (request.getParameter("page") != null) {
                page = Integer.parseInt(request.getParameter("page"));
            }

            // Calculate offset for pagination
            int offset = (page - 1) * RECORDS_PER_PAGE;

            // Get total records count for pagination
            int totalRecords = inventoryDAO.getTotalInventoryCount();
            int totalPages = (int) Math.ceil(totalRecords * 1.0 / RECORDS_PER_PAGE);

            // Get paginated inventory list
            List<BloodInventory> inventoryList = inventoryDAO.getInventoryPaginated(offset, RECORDS_PER_PAGE);

            request.setAttribute("inventoryList", inventoryList);
            request.setAttribute("totalPages", totalPages);
            request.setAttribute("currentPage", page);
            request.getRequestDispatcher("/views/inventory/list.jsp").forward(request, response);
        } catch (SQLException e) {
            handleError(request, response, "Error retrieving inventory: " + e.getMessage());
        }
    }

    private void searchInventory(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String searchTerm = request.getParameter("searchTerm");
            String searchType = request.getParameter("searchType"); // "bloodGroup" or "quantity"

            // Pagination parameters
            int page = 1;
            if (request.getParameter("page") != null) {
                page = Integer.parseInt(request.getParameter("page"));
            }
            int offset = (page - 1) * RECORDS_PER_PAGE;

            List<BloodInventory> inventoryList;
            int totalRecords;

            if (searchType.equals("bloodGroup")) {
                inventoryList = inventoryDAO.searchByBloodGroup(searchTerm, offset, RECORDS_PER_PAGE);
                totalRecords = inventoryDAO.getSearchByBloodGroupCount(searchTerm);
            } else {
                try {
                    int quantity = Integer.parseInt(searchTerm);
                    inventoryList = inventoryDAO.searchByQuantity(quantity, offset, RECORDS_PER_PAGE);
                    totalRecords = inventoryDAO.getSearchByQuantityCount(quantity);
                } catch (NumberFormatException e) {
                    handleError(request, response, "Please enter a valid number for quantity search");
                    return;
                }
            }

            int totalPages = (int) Math.ceil(totalRecords * 1.0 / RECORDS_PER_PAGE);

            request.setAttribute("inventoryList", inventoryList);
            request.setAttribute("totalPages", totalPages);
            request.setAttribute("currentPage", page);
            request.setAttribute("searchTerm", searchTerm);
            request.setAttribute("searchType", searchType);
            request.getRequestDispatcher("/views/inventory/list.jsp").forward(request, response);
        } catch (SQLException e) {
            handleError(request, response, "Error searching inventory: " + e.getMessage());
        }
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/views/inventory/add.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String bloodGroup = request.getParameter("bloodGroup");
            BloodInventory inventory = inventoryDAO.getInventoryByBloodGroup(bloodGroup);
            if (inventory != null) {
                request.setAttribute("inventory", inventory);
                request.getRequestDispatcher("/views/inventory/edit.jsp").forward(request, response);
            } else {
                handleError(request, response, "Blood group not found");
            }
        } catch (SQLException e) {
            handleError(request, response, "Error retrieving inventory: " + e.getMessage());
        }
    }

    private void confirmDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String bloodGroup = request.getParameter("bloodGroup");
        request.setAttribute("bloodGroup", bloodGroup);
        request.getRequestDispatcher("/views/inventory/confirmDelete.jsp").forward(request, response);
    }

    private void addInventory(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String bloodGroup = request.getParameter("bloodGroup");
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            Date lastUpdated = new Date(System.currentTimeMillis());

            // Validate input
            if (bloodGroup == null || bloodGroup.trim().isEmpty()) {
                handleError(request, response, "Blood group cannot be empty");
                return;
            }

            if (quantity < 0) {
                handleError(request, response, "Quantity cannot be negative");
                return;
            }

            BloodInventory newInventory = new BloodInventory(bloodGroup, quantity, lastUpdated);
            if (inventoryDAO.addInventory(newInventory)) {
                request.setAttribute("success", "Inventory added successfully!");
            } else {
                request.setAttribute("error", "Failed to add inventory");
            }
            listInventory(request, response);
        } catch (NumberFormatException e) {
            handleError(request, response, "Invalid quantity format");
        } catch (SQLException e) {
            handleError(request, response, "Database error: " + e.getMessage());
        }
    }

    private void updateInventory(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String bloodGroup = request.getParameter("bloodGroup");
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            Date lastUpdated = new Date(System.currentTimeMillis());

            // Validate input
            if (quantity < 0) {
                handleError(request, response, "Quantity cannot be negative");
                return;
            }

            BloodInventory inventory = new BloodInventory(bloodGroup, quantity, lastUpdated);
            if (inventoryDAO.updateInventory(inventory)) {
                request.setAttribute("success", "Inventory updated successfully!");
            } else {
                request.setAttribute("error", "Failed to update inventory");
            }
            listInventory(request, response);
        } catch (NumberFormatException e) {
            handleError(request, response, "Invalid quantity format");
        } catch (SQLException e) {
            handleError(request, response, "Database error: " + e.getMessage());
        }
    }

    private void deleteInventory(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String bloodGroup = request.getParameter("bloodGroup");
            if (inventoryDAO.deleteInventory(bloodGroup)) {
                request.setAttribute("success", bloodGroup + " inventory deleted successfully!");
            } else {
                request.setAttribute("error", "Failed to delete inventory");
            }
            listInventory(request, response);
        } catch (SQLException e) {
            handleError(request, response, "Database error: " + e.getMessage());
        }
    }

    private void handleError(HttpServletRequest request, HttpServletResponse response, String message)
            throws ServletException, IOException {
        request.setAttribute("error", message);
        listInventory(request, response);
    }
}