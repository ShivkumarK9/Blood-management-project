package com.blood.controller;

import com.blood.dao.RequestDAO;
import com.blood.model.Request;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RequestServlet")
public class RequestServlet extends HttpServlet {
    private RequestDAO requestDAO;

    @Override
    public void init() {
        requestDAO = new RequestDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if (action == null || action.equals("list")) {
                listRequests(request, response);
            } else if (action.equals("new")) {
                showNewForm(request, response);
            } else if (action.equals("edit")) {
                showEditForm(request, response);
            } else if (action.equals("approve")) {
                approveRequest(request, response);
            } else if (action.equals("reject")) {
                rejectRequest(request, response);
            } else if (action.equals("delete")) {
                deleteRequest(request, response);
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if (action.equals("add")) {
                addRequest(request, response);
            } else if (action.equals("update")) {
                updateRequest(request, response);
            } else {
                listRequests(request, response);
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    private void listRequests(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        // Get pagination parameters
        int page = 1;
        int pageSize = 5;

        if (request.getParameter("page") != null) {
            page = Integer.parseInt(request.getParameter("page"));
        }

        // Get search parameters
        String patientName = request.getParameter("patientName");
        String hospitalName = request.getParameter("hospitalName");
        String bloodGroup = request.getParameter("bloodGroup");
        String status = request.getParameter("status");

        List<Request> requests;
        int totalRecords;

        if (patientName != null || hospitalName != null || bloodGroup != null || status != null) {
            // Filtered search
            requests = requestDAO.searchRequests(patientName, hospitalName, bloodGroup, status, page, pageSize);
            totalRecords = requestDAO.getFilteredRequestCount(patientName, hospitalName, bloodGroup, status);
        } else {
            // Get all requests
            requests = requestDAO.getAllRequests(page, pageSize);
            totalRecords = requestDAO.getTotalRequestCount();
        }

        int totalPages = (int) Math.ceil((double) totalRecords / pageSize);

        request.setAttribute("requests", requests);
        request.setAttribute("currentPage", page);
        request.setAttribute("totalPages", totalPages);
        request.setAttribute("pageSize", pageSize);

        // Pass search parameters back to view
        request.setAttribute("patientName", patientName);
        request.setAttribute("hospitalName", hospitalName);
        request.setAttribute("bloodGroup", bloodGroup);
        request.setAttribute("status", status);

        request.getRequestDispatcher("/views/requests/list.jsp").forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/views/requests/add.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int id = Integer.parseInt(request.getParameter("id"));
        Request requestObj = requestDAO.getRequestById(id);
        request.setAttribute("request", requestObj);
        request.getRequestDispatcher("/views/requests/edit.jsp").forward(request, response);
    }

    private void addRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        String patientName = request.getParameter("patientName");
        String hospitalName = request.getParameter("hospitalName");
        String bloodGroup = request.getParameter("bloodGroup");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        Date requestDate = new Date(System.currentTimeMillis());

        Request newRequest = new Request(patientName, hospitalName, bloodGroup, quantity, requestDate, "Pending");
        requestDAO.addRequest(newRequest);
        response.sendRedirect("RequestServlet?action=list");
    }

    private void updateRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int id = Integer.parseInt(request.getParameter("id"));
        String patientName = request.getParameter("patientName");
        String hospitalName = request.getParameter("hospitalName");
        String bloodGroup = request.getParameter("bloodGroup");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        String status = request.getParameter("status");

        Request requestObj = new Request();
        requestObj.setId(id);
        requestObj.setPatientName(patientName);
        requestObj.setHospitalName(hospitalName);
        requestObj.setBloodGroup(bloodGroup);
        requestObj.setQuantity(quantity);
        requestObj.setStatus(status);

        requestDAO.updateRequest(requestObj);
        response.sendRedirect("RequestServlet?action=list");
    }

    private void approveRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int id = Integer.parseInt(request.getParameter("id"));
        requestDAO.updateRequestStatus(id, "Approved");
        response.sendRedirect("RequestServlet?action=list");
    }

    private void rejectRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int id = Integer.parseInt(request.getParameter("id"));
        requestDAO.updateRequestStatus(id, "Rejected");
        response.sendRedirect("RequestServlet?action=list");
    }

    private void deleteRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int id = Integer.parseInt(request.getParameter("id"));
        requestDAO.deleteRequest(id);
        response.sendRedirect("RequestServlet?action=list");
    }
}