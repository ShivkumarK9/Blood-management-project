package com.blood.controller;

import com.blood.dao.DonorDAO;
import com.blood.model.Donor;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DonorServlet")
public class DonorServlet extends HttpServlet {
    private DonorDAO donorDAO;

    @Override
    public void init() {
        donorDAO = new DonorDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            action = "list";
        }

        try {
            switch (action) {
                case "add":
                    addDonor(request, response);
                    break;
                case "update":
                    updateDonor(request, response);
                    break;
                case "delete":
                    deleteDonor(request, response);
                    break;
                default:
                    listDonors(request, response);
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            action = "list";
        }

        try {
            switch (action) {
                case "new":
                    showNewForm(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "delete":
                    deleteDonor(request, response);
                    break;
                case "list":
                default:
                    listDonors(request, response);
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    private void listDonors(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("donors", donorDAO.getAllDonors());
        request.getRequestDispatcher("views/donorList.jsp").forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("views/addDonor.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Donor existingDonor = donorDAO.getDonorById(id);
        request.setAttribute("donor", existingDonor);
        request.getRequestDispatcher("views/editDonor.jsp").forward(request, response);
    }

    private void addDonor(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        int age = Integer.parseInt(request.getParameter("age"));
        String bloodGroup = request.getParameter("bloodGroup");
        String contact = request.getParameter("contact");
        String address = request.getParameter("address");
        Date lastDonationDate = parseDate(request.getParameter("lastDonationDate"));
        boolean isAvailable = request.getParameter("isAvailable") != null;

        Donor newDonor = new Donor(name, age, bloodGroup, contact, address, lastDonationDate, isAvailable);

        if (donorDAO.addDonor(newDonor)) {
            request.setAttribute("message", "Donor added successfully");
        } else {
            request.setAttribute("error", "Failed to add donor");
        }

        listDonors(request, response);
    }

    private void updateDonor(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        int age = Integer.parseInt(request.getParameter("age"));
        String bloodGroup = request.getParameter("bloodGroup");
        String contact = request.getParameter("contact");
        String address = request.getParameter("address");
        Date lastDonationDate = parseDate(request.getParameter("lastDonationDate"));
        boolean isAvailable = request.getParameter("isAvailable") != null;

        Donor donor = new Donor(name, age, bloodGroup, contact, address, lastDonationDate, isAvailable);
        donor.setId(id);

        if (donorDAO.updateDonor(donor)) {
            request.setAttribute("message", "Donor updated successfully");
        } else {
            request.setAttribute("error", "Failed to update donor");
        }

        listDonors(request, response);
    }

    private void deleteDonor(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));

        if (donorDAO.deleteDonor(id)) {
            request.setAttribute("message", "Donor deleted successfully");
        } else {
            request.setAttribute("error", "Failed to delete donor");
        }

        listDonors(request, response);
    }

    private Date parseDate(String dateStr) {
        if (dateStr == null || dateStr.isEmpty()) {
            return null;
        }

        try {
            return new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
        } catch (ParseException e) {
            return null;
        }
    }
}