package com.blood.model;

import java.util.Date;

public class BloodInventory {
    private String bloodGroup;
    private int quantity;
    private Date lastUpdated;

    public BloodInventory() {}

    public BloodInventory(String bloodGroup, int quantity, Date lastUpdated) {
        this.bloodGroup = bloodGroup;
        this.quantity = quantity;
        this.lastUpdated = lastUpdated;
    }

    // Getters and Setters
    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}