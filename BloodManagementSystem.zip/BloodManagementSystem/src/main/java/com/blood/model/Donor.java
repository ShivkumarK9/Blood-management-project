package com.blood.model;


import java.util.Date;

public class Donor {
    private int id;
    private String name;
    private int age;
    private String bloodGroup;
    private String contact;
    private String address;
    private Date lastDonationDate;
    private boolean isAvailable;

    // Constructors, getters, and setters
    public Donor() {}

    public Donor(String name, int age, String bloodGroup, String contact,
                 String address, Date lastDonationDate, boolean isAvailable) {
        this.name = name;
        this.age = age;
        this.bloodGroup = bloodGroup;
        this.contact = contact;
        this.address = address;
        this.lastDonationDate = lastDonationDate;
        this.isAvailable = isAvailable;
    }

    // Getters and setters for all fields
    // ...

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Date getLastDonationDate() {
        return lastDonationDate;
    }

    public void setLastDonationDate(Date lastDonationDate) {
        this.lastDonationDate = lastDonationDate;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }
}
