package com.blood.model;

import java.util.Date;

public class Request {
    private int id;
    private String patientName;
    private String hospitalName;
    private String bloodGroup;
    private int quantity;
    private Date requestDate;
    private String status;

    public Request() {}

    public Request(String patientName, String hospitalName, String bloodGroup,
                   int quantity, Date requestDate, String status) {
        this.patientName = patientName;
        this.hospitalName = hospitalName;
        this.bloodGroup = bloodGroup;
        this.quantity = quantity;
        this.requestDate = requestDate;
        this.status = status;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getPatientName() { return patientName; }
    public void setPatientName(String patientName) { this.patientName = patientName; }
    public String getHospitalName() { return hospitalName; }
    public void setHospitalName(String hospitalName) { this.hospitalName = hospitalName; }
    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public Date getRequestDate() { return requestDate; }
    public void setRequestDate(Date requestDate) { this.requestDate = requestDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}