package com.blood.dao;

import com.blood.model.Request;
import com.blood.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RequestDAO {

    // Create a new blood request
    public boolean addRequest(Request request) throws SQLException {
        String sql = "INSERT INTO requests (patient_name, hospital_name, blood_group, quantity, request_date, status) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, request.getPatientName());
            stmt.setString(2, request.getHospitalName());
            stmt.setString(3, request.getBloodGroup());
            stmt.setInt(4, request.getQuantity());
            stmt.setDate(5, new java.sql.Date(request.getRequestDate().getTime()));
            stmt.setString(6, request.getStatus());

            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        request.setId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
            return false;
        }
    }

    // Get all requests with pagination
    public List<Request> getAllRequests(int page, int pageSize) throws SQLException {
        List<Request> requests = new ArrayList<>();
        String sql = "SELECT * FROM requests ORDER BY request_date DESC LIMIT ? OFFSET ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, pageSize);
            stmt.setInt(2, (page - 1) * pageSize);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    requests.add(extractRequestFromResultSet(rs));
                }
            }
        }
        return requests;
    }

    // Get total count of requests
    public int getTotalRequestCount() throws SQLException {
        String sql = "SELECT COUNT(*) FROM requests";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt(1);
            }
            return 0;
        }
    }

    // Search requests with filters and pagination
    public List<Request> searchRequests(String patientName, String hospitalName,
                                        String bloodGroup, String status,
                                        int page, int pageSize) throws SQLException {
        List<Request> requests = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM requests WHERE 1=1");
        List<Object> parameters = new ArrayList<>();

        if (patientName != null && !patientName.isEmpty()) {
            sql.append(" AND patient_name LIKE ?");
            parameters.add("%" + patientName + "%");
        }
        if (hospitalName != null && !hospitalName.isEmpty()) {
            sql.append(" AND hospital_name LIKE ?");
            parameters.add("%" + hospitalName + "%");
        }
        if (bloodGroup != null && !bloodGroup.isEmpty()) {
            sql.append(" AND blood_group = ?");
            parameters.add(bloodGroup);
        }
        if (status != null && !status.isEmpty()) {
            sql.append(" AND status = ?");
            parameters.add(status);
        }

        sql.append(" ORDER BY request_date DESC LIMIT ? OFFSET ?");
        parameters.add(pageSize);
        parameters.add((page - 1) * pageSize);

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < parameters.size(); i++) {
                stmt.setObject(i + 1, parameters.get(i));
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    requests.add(extractRequestFromResultSet(rs));
                }
            }
        }
        return requests;
    }

    // Get count of filtered requests
    public int getFilteredRequestCount(String patientName, String hospitalName,
                                       String bloodGroup, String status) throws SQLException {
        StringBuilder sql = new StringBuilder("SELECT COUNT(*) FROM requests WHERE 1=1");
        List<Object> parameters = new ArrayList<>();

        if (patientName != null && !patientName.isEmpty()) {
            sql.append(" AND patient_name LIKE ?");
            parameters.add("%" + patientName + "%");
        }
        if (hospitalName != null && !hospitalName.isEmpty()) {
            sql.append(" AND hospital_name LIKE ?");
            parameters.add("%" + hospitalName + "%");
        }
        if (bloodGroup != null && !bloodGroup.isEmpty()) {
            sql.append(" AND blood_group = ?");
            parameters.add(bloodGroup);
        }
        if (status != null && !status.isEmpty()) {
            sql.append(" AND status = ?");
            parameters.add(status);
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < parameters.size(); i++) {
                stmt.setObject(i + 1, parameters.get(i));
            }

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
                return 0;
            }
        }
    }

    // Get request by ID
    public Request getRequestById(int id) throws SQLException {
        String sql = "SELECT * FROM requests WHERE id = ?";
        Request request = null;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    request = extractRequestFromResultSet(rs);
                }
            }
        }
        return request;
    }

    // Update request
    public boolean updateRequest(Request request) throws SQLException {
        String sql = "UPDATE requests SET patient_name = ?, hospital_name = ?, blood_group = ?, " +
                "quantity = ?, status = ? WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, request.getPatientName());
            stmt.setString(2, request.getHospitalName());
            stmt.setString(3, request.getBloodGroup());
            stmt.setInt(4, request.getQuantity());
            stmt.setString(5, request.getStatus());
            stmt.setInt(6, request.getId());

            return stmt.executeUpdate() > 0;
        }
    }

    // Update request status only
    public boolean updateRequestStatus(int id, String status) throws SQLException {
        String sql = "UPDATE requests SET status = ? WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, status);
            stmt.setInt(2, id);

            return stmt.executeUpdate() > 0;
        }
    }

    // Delete request
    public boolean deleteRequest(int id) throws SQLException {
        String sql = "DELETE FROM requests WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }

    // Helper method to extract Request from ResultSet
    private Request extractRequestFromResultSet(ResultSet rs) throws SQLException {
        Request request = new Request();
        request.setId(rs.getInt("id"));
        request.setPatientName(rs.getString("patient_name"));
        request.setHospitalName(rs.getString("hospital_name"));
        request.setBloodGroup(rs.getString("blood_group"));
        request.setQuantity(rs.getInt("quantity"));
        request.setRequestDate(rs.getDate("request_date"));
        request.setStatus(rs.getString("status"));
        return request;
    }
}