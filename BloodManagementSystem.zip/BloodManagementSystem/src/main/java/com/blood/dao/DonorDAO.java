package com.blood.dao;

import com.blood.model.Donor;
import com.blood.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DonorDAO {

    // Add a new donor
    public boolean addDonor(Donor donor) {
        String sql = "INSERT INTO donors (name, age, blood_group, contact, address, last_donation_date, is_available) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, donor.getName());
            stmt.setInt(2, donor.getAge());
            stmt.setString(3, donor.getBloodGroup());
            stmt.setString(4, donor.getContact());
            stmt.setString(5, donor.getAddress());
            stmt.setDate(6, new java.sql.Date(donor.getLastDonationDate().getTime()));
            stmt.setBoolean(7, donor.isAvailable());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get all donors
    public List<Donor> getAllDonors() {
        List<Donor> donors = new ArrayList<>();
        String sql = "SELECT * FROM donors";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Donor donor = new Donor();
                donor.setId(rs.getInt("id"));
                donor.setName(rs.getString("name"));
                donor.setAge(rs.getInt("age"));
                donor.setBloodGroup(rs.getString("blood_group"));
                donor.setContact(rs.getString("contact"));
                donor.setAddress(rs.getString("address"));
                donor.setLastDonationDate(rs.getDate("last_donation_date"));
                donor.setAvailable(rs.getBoolean("is_available"));

                donors.add(donor);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return donors;
    }

    // Get donor by ID
    public Donor getDonorById(int id) {
        String sql = "SELECT * FROM donors WHERE id = ?";
        Donor donor = null;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    donor = new Donor();
                    donor.setId(rs.getInt("id"));
                    donor.setName(rs.getString("name"));
                    donor.setAge(rs.getInt("age"));
                    donor.setBloodGroup(rs.getString("blood_group"));
                    donor.setContact(rs.getString("contact"));
                    donor.setAddress(rs.getString("address"));
                    donor.setLastDonationDate(rs.getDate("last_donation_date"));
                    donor.setAvailable(rs.getBoolean("is_available"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return donor;
    }

    // Update donor
    public boolean updateDonor(Donor donor) {
        String sql = "UPDATE donors SET name=?, age=?, blood_group=?, contact=?, address=?, last_donation_date=?, is_available=? WHERE id=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, donor.getName());
            stmt.setInt(2, donor.getAge());
            stmt.setString(3, donor.getBloodGroup());
            stmt.setString(4, donor.getContact());
            stmt.setString(5, donor.getAddress());
            stmt.setDate(6, new java.sql.Date(donor.getLastDonationDate().getTime()));
            stmt.setBoolean(7, donor.isAvailable());
            stmt.setInt(8, donor.getId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete donor
    public boolean deleteDonor(int id) {
        String sql = "DELETE FROM donors WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}