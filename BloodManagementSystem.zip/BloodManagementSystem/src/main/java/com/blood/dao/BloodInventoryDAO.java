package com.blood.dao;

import com.blood.model.BloodInventory;
import com.blood.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BloodInventoryDAO {
    public List<BloodInventory> getAllInventory() throws SQLException {
        List<BloodInventory> inventoryList = new ArrayList<>();
        String sql = "SELECT * FROM blood_inventory ORDER BY blood_group";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                inventoryList.add(extractInventoryFromResultSet(rs));
            }
        }
        return inventoryList;
    }

    public BloodInventory getInventoryByBloodGroup(String bloodGroup) throws SQLException {
        String sql = "SELECT * FROM blood_inventory WHERE blood_group = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, bloodGroup);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() ? extractInventoryFromResultSet(rs) : null;
            }
        }
    }

    public boolean addInventory(BloodInventory inventory) throws SQLException {
        String sql = "INSERT INTO blood_inventory (blood_group, quantity, last_updated) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            setInventoryParameters(stmt, inventory);
            return stmt.executeUpdate() > 0;
        }
    }

    public boolean updateInventory(BloodInventory inventory) throws SQLException {
        String sql = "UPDATE blood_inventory SET quantity = ?, last_updated = ? WHERE blood_group = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, inventory.getQuantity());
            stmt.setDate(2, new java.sql.Date(inventory.getLastUpdated().getTime()));
            stmt.setString(3, inventory.getBloodGroup());

            return stmt.executeUpdate() > 0;
        }
    }

    public boolean deleteInventory(String bloodGroup) throws SQLException {
        String sql = "DELETE FROM blood_inventory WHERE blood_group = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, bloodGroup);
            return stmt.executeUpdate() > 0;
        }
    }

    public int getTotalInventoryCount() throws SQLException {
        String sql = "SELECT COUNT(*) FROM blood_inventory";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    public List<BloodInventory> getInventoryPaginated(int offset, int limit) throws SQLException {
        List<BloodInventory> inventoryList = new ArrayList<>();
        String sql = "SELECT * FROM blood_inventory ORDER BY blood_group LIMIT ? OFFSET ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, limit);
            stmt.setInt(2, offset);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    inventoryList.add(extractInventoryFromResultSet(rs));
                }
            }
        }
        return inventoryList;
    }

    public List<BloodInventory> searchByBloodGroup(String searchTerm, int offset, int limit) throws SQLException {
        List<BloodInventory> inventoryList = new ArrayList<>();
        String sql = "SELECT * FROM blood_inventory WHERE blood_group LIKE ? ORDER BY blood_group LIMIT ? OFFSET ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, "%" + searchTerm + "%");
            stmt.setInt(2, limit);
            stmt.setInt(3, offset);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    inventoryList.add(extractInventoryFromResultSet(rs));
                }
            }
        }
        return inventoryList;
    }

    public int getSearchByBloodGroupCount(String searchTerm) throws SQLException {
        String sql = "SELECT COUNT(*) FROM blood_inventory WHERE blood_group LIKE ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, "%" + searchTerm + "%");

            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    public List<BloodInventory> searchByQuantity(int quantity, int offset, int limit) throws SQLException {
        List<BloodInventory> inventoryList = new ArrayList<>();
        String sql = "SELECT * FROM blood_inventory WHERE quantity = ? ORDER BY blood_group LIMIT ? OFFSET ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, quantity);
            stmt.setInt(2, limit);
            stmt.setInt(3, offset);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    inventoryList.add(extractInventoryFromResultSet(rs));
                }
            }
        }
        return inventoryList;
    }

    public int getSearchByQuantityCount(int quantity) throws SQLException {
        String sql = "SELECT COUNT(*) FROM blood_inventory WHERE quantity = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, quantity);

            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    private BloodInventory extractInventoryFromResultSet(ResultSet rs) throws SQLException {
        BloodInventory inventory = new BloodInventory();
        inventory.setBloodGroup(rs.getString("blood_group"));
        inventory.setQuantity(rs.getInt("quantity"));
        inventory.setLastUpdated(rs.getDate("last_updated"));
        return inventory;
    }

    private void setInventoryParameters(PreparedStatement stmt, BloodInventory inventory)
            throws SQLException {
        stmt.setString(1, inventory.getBloodGroup());
        stmt.setInt(2, inventory.getQuantity());
        stmt.setDate(3, new java.sql.Date(inventory.getLastUpdated().getTime()));
    }
}